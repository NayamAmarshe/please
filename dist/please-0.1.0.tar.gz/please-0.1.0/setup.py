# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['please']

package_data = \
{'': ['*']}

install_requires = \
['art>=5.6,<6.0',
 'pyfiglet>=0.8.post1,<0.9',
 'python-jsonstore>=1.3.0,<2.0.0',
 'rich>=12.3.0,<13.0.0',
 'typer>=0.4.1,<0.5.0']

setup_kwargs = {
    'name': 'please',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Zeffo',
    'author_email': '25067102+NayamAmarshe@users.noreply.github.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
